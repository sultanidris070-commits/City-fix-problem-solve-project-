# CityFix — Vercel-ready starter

A responsive civic-tech demo built with React + Vite + Leaflet.

## Run locally
1. Install Node.js (18+ recommended).
2. Extract this ZIP.
3. Open the extracted folder in a terminal.
4. Run `npm install`
5. Run `npm run dev`
6. Open the local URL shown in the terminal.

## Deploy to Vercel
1. Push this project folder to a GitHub repository.
2. In Vercel, choose **Add New → Project** and import that repository.
3. Framework preset: **Vite**.
4. Build command: `npm run build`
5. Output directory: `dist`
6. Click **Deploy**.

## Demo admin access
- Email: `admin@cityfix.demo`
- Password: `CityFix@123`

This is a front-end demonstration login only. It is NOT secure production authentication.
Complaints are stored in the current browser's localStorage, not a shared server database.
For a real public launch, connect secure backend authentication, database, image storage,
server-side role checks, rate limiting, and privacy controls. Never use demo credentials
for a real account.

## Map data
The map uses OpenStreetMap tiles and Leaflet. Demo markers are illustrative sample locations,
not verified live complaints. Internet access is required for map tiles.
