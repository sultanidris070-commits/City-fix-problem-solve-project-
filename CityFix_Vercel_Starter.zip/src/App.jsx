import React, { useEffect, useMemo, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";

const STORAGE_KEY = "cityfix_demo_complaints_v1";
const demoItems = [
  { id:"CF-DEMO-101", title:"Garbage collection delay", category:"Garbage", city:"Delhi", country:"India", lat:28.7041, lng:77.1025, status:"In Progress", demo:true, description:"Illustrative demo marker. Not a verified complaint." },
  { id:"CF-DEMO-102", title:"Road maintenance concern", category:"Road Damage", city:"Gorakhpur", country:"India", lat:26.7606, lng:83.3732, status:"Pending Review", demo:true, description:"Illustrative demo marker. Not a verified complaint." },
  { id:"CF-DEMO-103", title:"Drainage maintenance", category:"Drainage", city:"London", country:"United Kingdom", lat:51.5072, lng:-0.1276, status:"Resolved", demo:true, description:"Illustrative demo marker. Not a verified complaint." },
  { id:"CF-DEMO-104", title:"Public water access", category:"Water Supply", city:"Nairobi", country:"Kenya", lat:-1.2921, lng:36.8219, status:"Pending Review", demo:true, description:"Illustrative demo marker. Not a verified complaint." },
  { id:"CF-DEMO-105", title:"Streetlight maintenance", category:"Streetlight", city:"New York", country:"USA", lat:40.7128, lng:-74.006, status:"In Progress", demo:true, description:"Illustrative demo marker. Not a verified complaint." }
];

function readComplaints() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); } catch { return []; }
}
function saveComplaints(items) { localStorage.setItem(STORAGE_KEY, JSON.stringify(items)); }
function makeId() { return "CF-" + Date.now().toString().slice(-8); }

function MapView({ mode, complaints }) {
  const center = mode === "local" ? [26.7606, 83.3732] : [20, 0];
  const zoom = mode === "local" ? 11 : 2;
  const points = [...demoItems, ...complaints.filter(x => Number.isFinite(x.lat) && Number.isFinite(x.lng))];
  return <MapContainer key={mode} center={center} zoom={zoom} scrollWheelZoom className="map">
    <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
    {points.map(p => <Marker key={p.id} position={[p.lat,p.lng]}>
      <Popup><strong>{p.title}</strong><br/>{p.city}, {p.country}<br/>Status: {p.status}<br/><small>{p.demo ? "DEMO DATA — not a verified complaint" : p.id}</small></Popup>
    </Marker>)}
  </MapContainer>;
}

export default function App() {
  const [page, setPage] = useState("home");
  const [complaints, setComplaints] = useState(readComplaints);
  const [admin, setAdmin] = useState(false);
  const [mapMode, setMapMode] = useState("global");
  const [notice, setNotice] = useState("");
  const [form, setForm] = useState({title:"",category:"Garbage",description:"",city:"",country:"India",lat:"",lng:""});
  const [login, setLogin] = useState({email:"",password:""});
  const [search, setSearch] = useState("");

  useEffect(() => saveComplaints(complaints), [complaints]);
  const allItems = useMemo(() => [...complaints], [complaints]);
  const filtered = allItems.filter(c => [c.id,c.title,c.category,c.city,c.status].join(" ").toLowerCase().includes(search.toLowerCase()));
  const stats = [
    ["Total reports", complaints.length + demoItems.length],
    ["Pending review", complaints.filter(c=>c.status==="Pending Review").length + demoItems.filter(c=>c.status==="Pending Review").length],
    ["In progress", complaints.filter(c=>c.status==="In Progress").length + demoItems.filter(c=>c.status==="In Progress").length],
    ["Resolved", complaints.filter(c=>c.status==="Resolved").length + demoItems.filter(c=>c.status==="Resolved").length]
  ];
  function submitComplaint(e) {
    e.preventDefault();
    if (!form.title.trim() || !form.description.trim() || !form.city.trim() || !form.country.trim()) {
      setNotice("Please complete all required fields."); return;
    }
    const item = { ...form, id:makeId(), status:"Pending Review", createdAt:new Date().toISOString(), demo:false,
      lat: form.lat.trim() ? Number(form.lat) : null, lng: form.lng.trim() ? Number(form.lng) : null };
    if ((item.lat !== null && !Number.isFinite(item.lat)) || (item.lng !== null && !Number.isFinite(item.lng)) ||
        ((item.lat === null) !== (item.lng === null)) ||
        (item.lat !== null && (Math.abs(item.lat)>90 || Math.abs(item.lng)>180))) {
      setNotice("Enter valid latitude and longitude together, or leave both blank."); return;
    }
    setComplaints(prev => [item,...prev]);
    setForm({title:"",category:"Garbage",description:"",city:"",country:"India",lat:"",lng:""});
    setNotice("Complaint saved in this browser. Your Complaint ID is " + item.id);
    setPage("track");
  }
  function doLogin(e) {
    e.preventDefault();
    if (login.email === "admin@cityfix.demo" && login.password === "CityFix@123") {
      setAdmin(true); setPage("admin"); setNotice("Demo admin login successful.");
    } else setNotice("Login details did not match the demo credentials in README.md.");
  }
  function updateStatus(id,status) { setComplaints(prev=>prev.map(c=>c.id===id?{...c,status,updatedAt:new Date().toISOString()}:c)); }
  function nav(p) { setNotice(""); setPage(p); }

  return <div className="app">
    <header className="topbar">
      <button className="brand" onClick={()=>nav("home")}><span className="brand-mark">C</span><span>CITY<span className="green">FIX</span><small>Your City. Your Voice. Your Fix.</small></span></button>
      <nav>
        <button onClick={()=>nav("home")}>Home</button><button onClick={()=>nav("report")}>Report Issue</button><button onClick={()=>nav("track")}>Track</button><button onClick={()=>nav("map")}>World Map</button>
        <button className="nav-admin" onClick={()=>nav(admin?"admin":"login")}>{admin?"Admin Panel":"Admin Login"}</button>
      </nav>
    </header>

    <main>
      {notice && <div className="notice"><span>{notice}</span><button onClick={()=>setNotice("")}>×</button></div>}
      {page==="home" && <>
        <section className="hero">
          <div className="hero-copy"><div className="eyebrow"><span className="pulse"></span> CIVIC ISSUES. CLEARER ACTION.</div>
            <h1>Make your city<br/><em>better, together.</em></h1>
            <p>Report civic issues, follow their progress and explore public issue information on an interactive map.</p>
            <div className="actions"><button className="primary" onClick={()=>nav("report")}>Report an issue <b>→</b></button><button className="secondary" onClick={()=>nav("map")}>Explore world map</button></div>
            <div className="trust-note">Independent civic-tech demonstration · Not a government website</div>
          </div>
          <div className="hero-art"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="globe">🌍</div><div className="floating-card"><span className="pin">●</span><div><b>Local voices matter</b><small>One report can start a conversation.</small></div></div></div>
        </section>
        <section className="stats">{stats.map(([label,value])=><div className="stat" key={label}><strong>{value}</strong><span>{label}</span></div>)}</section>
        <section className="section"><div className="section-head"><div><div className="eyebrow">HOW CITYFIX WORKS</div><h2>From report to follow-up.</h2></div><p>A simple way to organize civic concerns and keep track of updates.</p></div>
          <div className="steps"><article><span>01</span><h3>Report an issue</h3><p>Share the problem, category and location.</p></article><article><span>02</span><h3>Track progress</h3><p>Use your complaint ID to see the latest status in this demo.</p></article><article><span>03</span><h3>Build awareness</h3><p>Explore clearly labelled sample civic information on the map.</p></article></div>
        </section>
      </>}
      {page==="report" && <section className="form-layout"><div><div className="eyebrow">CITIZEN REPORT</div><h1 className="page-title">Report a civic issue.</h1><p className="muted">Fields marked * are required. Avoid sharing sensitive personal information.</p><div className="info-panel"><b>What happens next?</b><p>Your report is saved in this browser demo and assigned a Complaint ID. It is not automatically sent to a government department.</p></div></div>
        <form className="panel form" onSubmit={submitComplaint}>
          <label>Issue title *<input value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="e.g. Garbage not collected"/></label>
          <label>Category *<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{["Garbage","Water Supply","Road Damage","Drainage","Pollution","Streetlight","Public Infrastructure","Other"].map(x=><option>{x}</option>)}</select></label>
          <label>Description *<textarea rows="4" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Describe the issue clearly..."/></label>
          <div className="two"><label>City *<input value={form.city} onChange={e=>setForm({...form,city:e.target.value})} placeholder="e.g. Gorakhpur"/></label><label>Country *<input value={form.country} onChange={e=>setForm({...form,country:e.target.value})} /></label></div>
          <div className="two"><label>Latitude (optional)<input value={form.lat} onChange={e=>setForm({...form,lat:e.target.value})} placeholder="26.7606"/></label><label>Longitude (optional)<input value={form.lng} onChange={e=>setForm({...form,lng:e.target.value})} placeholder="83.3732"/></label></div>
          <button className="primary full">Submit complaint <b>→</b></button>
          <small className="muted">Demo version: no image upload or server-side storage is configured.</small>
        </form></section>}
      {page==="track" && <section className="section"><div className="eyebrow">COMPLAINT TRACKING</div><h1 className="page-title">Your reports.</h1><p className="muted">Reports created in this browser appear below.</p>
        {complaints.length===0?<div className="empty panel">No reports yet. <button className="text-button" onClick={()=>nav("report")}>Submit your first report →</button></div>:<div className="report-list">{complaints.map(c=><article className="report-card panel" key={c.id}><div><span className="tag">{c.category}</span><h3>{c.title}</h3><p>{c.city}, {c.country} · {c.id}</p></div><span className={"status "+c.status.toLowerCase().replaceAll(" ","-")}>{c.status}</span></article>)}</div>}
      </section>}
      {page==="map" && <section className="section map-section"><div className="section-head"><div><div className="eyebrow">CITYFIX EXPLORER</div><h1 className="page-title">Civic issues, on the map.</h1><p className="muted">Explore illustrative demo markers. They are not verified live complaints.</p></div><div className="switch"><button className={mapMode==="global"?"selected":""} onClick={()=>setMapMode("global")}>🌍 Global</button><button className={mapMode==="local"?"selected":""} onClick={()=>setMapMode("local")}>📍 Local pilot</button></div></div><MapView mode={mapMode} complaints={complaints}/><div className="map-legend"><span><i className="dot"></i> Demo issue markers</span><span>Map data © OpenStreetMap contributors</span></div></section>}
      {page==="login" && <section className="login-wrap"><form className="panel form login" onSubmit={doLogin}><div className="eyebrow">RESTRICTED AREA</div><h1 className="page-title">Admin login</h1><p className="muted">Use the demo credentials provided in README.md.</p><label>Email<input type="email" value={login.email} onChange={e=>setLogin({...login,email:e.target.value})} required/></label><label>Password<input type="password" value={login.password} onChange={e=>setLogin({...login,password:e.target.value})} required/></label><button className="primary full">Sign in</button></form></section>}
      {page==="admin" && <section className="section"><div className="section-head"><div><div className="eyebrow">ADMIN WORKSPACE · DEMO MODE</div><h1 className="page-title">Complaint management.</h1><p className="muted">Update the status of reports saved in this browser.</p></div><button className="secondary" onClick={()=>{setAdmin(false);nav("home")}}>Log out</button></div><div className="admin-tools"><input placeholder="Search complaints..." value={search} onChange={e=>setSearch(e.target.value)}/><span>{filtered.length} report(s)</span></div><div className="table-wrap panel"><table><thead><tr><th>Complaint</th><th>Location</th><th>ID</th><th>Status</th><th>Update status</th></tr></thead><tbody>{filtered.map(c=><tr key={c.id}><td><b>{c.title}</b><small>{c.category}</small></td><td>{c.city}, {c.country}</td><td>{c.id}</td><td>{c.status}</td><td><select value={c.status} onChange={e=>updateStatus(c.id,e.target.value)}><option>Pending Review</option><option>In Progress</option><option>Resolved</option><option>Rejected</option></select></td></tr>)}</tbody></table>{filtered.length===0&&<div className="empty">No matching reports.</div>}</div></section>}
    </main>
    <footer><div className="footer-brand"><span className="brand-mark">C</span><b>CITYFIX</b></div><p>Your City. Your Voice. Your Fix.</p><small>Independent civic-tech project · Demo data is illustrative · Not affiliated with any government authority.</small><span>© 2026 CityFix</span></footer>
  </div>;
}